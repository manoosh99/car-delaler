package birzeit.edu.RESTcon;

import java.util.List;

public class Car {

    private int year;
    private String make;
    private String distance;
    private String model;
    private double price;
    private boolean accidents;

    public static List<Car> carsList;

    public Car() {
    }

    public Car(int year, String make, String distance, String model, double price, boolean accidents) {
        this.year = year;
        this.make = make;
        this.distance = distance;
        this.model = model;
        this.price = price;
        this.accidents = accidents;
    }

    @Override
    public String toString() {
        return "Car information: \n\n" +
                " year=" + year +
                "\n make='" + make + '\'' +
                "\n distance='" + distance + '\'' +
                "\n model='" + model + '\'' +
                "\n price=" + price +
                "\n accidents=" + accidents ;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isAccidents() {
        return accidents;
    }

    public void setAccidents(boolean accidents) {
        this.accidents = accidents;
    }




}
