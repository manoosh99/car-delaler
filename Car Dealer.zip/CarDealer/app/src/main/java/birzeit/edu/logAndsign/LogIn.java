package birzeit.edu.logAndsign;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import birzeit.edu.CustomerPackage.HomeActivity;
import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;

public class LogIn extends AppCompatActivity {

    SharedPrefManager sharedPrefManager;
    SharedPrefManagerE sharedPrefManagerE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setPositiveButton("OK", null);

        Button log = findViewById(R.id.log);

        final EditText email = findViewById(R.id.log_email);
        final EditText pass = findViewById(R.id.log_pass);

        final CheckBox cb = findViewById(R.id.remember);
        sharedPrefManager = SharedPrefManager.getInstance(LogIn.this);
        if (sharedPrefManager.readString("userName", "noValue").compareTo("noValue") != 0) {
            email.setText(sharedPrefManager.readString("userName", "noValue"));
            pass.setText(sharedPrefManager.readString("password", "noValue"));
        }

        Button sign = findViewById(R.id.signUP);
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LogIn.this, SignUp.class);
                LogIn.this.startActivity(intent);
                finish();
            }

    });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DataBaseHelper dataBaseHelper;
                dataBaseHelper = new DataBaseHelper(LogIn.this, "DataBaseProject", null, 1);
                Cursor search = dataBaseHelper.searchCostomers("email", email.getText().toString());
                if (search.moveToNext()) {
                    String retPass = search.getString(search.getColumnIndex("PASSWORD"));
                    String hashedPassword= null;

                    try {
                        hashedPassword = toHexString(getSHA(pass.getText().toString()));

                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    }

                    if (hashedPassword.compareTo(retPass) == 0) {
                        //go intent
                        if (cb.isChecked()) {

                            sharedPrefManager.writeString("userName", email.getText().toString());
                            sharedPrefManager.writeString("password", pass.getText().toString());



                        } else {
                            sharedPrefManager.delete("userName");
                            sharedPrefManager.delete("password");
                        }

                        sharedPrefManager.writeString("identity", email.getText().toString());
                        Intent intent;

                        intent = new Intent(LogIn.this, HomeActivity.class);
                        LogIn.this.startActivity(intent);
                        finish();

                    } else {
                        alertDialogBuilder.setTitle("Wrong password");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }

                } else {
                    alertDialogBuilder.setTitle("Wrong email");
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();

                }
                //save logged user email
                sharedPrefManagerE = SharedPrefManagerE.getInstance(LogIn.this);
                sharedPrefManagerE.writeString("email", email.getText().toString());
            }
        });

    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
                Intent intent = new Intent(LogIn.this, logOrSign.class);
                LogIn.this.startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}