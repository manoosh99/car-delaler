package birzeit.edu.CustomerPackage.ui.profile;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProviders;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import birzeit.edu.CustomerPackage.ui.Findus.FindusViewModel;
import birzeit.edu.DB.Customer;
import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;
import birzeit.edu.logAndsign.SharedPrefManagerE;
import static android.graphics.Color.RED;

public class ProfileFragment extends Fragment {
    private Object ProfileViewModel;
    int correctFields = 0;
    SharedPrefManagerE sharedPrefManagerE;
    public static ProfileFragment newInstance() {
        return new ProfileFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        ProfileViewModel =
                ViewModelProviders.of(this).get(FindusViewModel.class);
        final View root = inflater.inflate(R.layout.profile_fragment, container, false);

        //create buttons and find by id
        final Button updateButton = root.findViewById(R.id.update);
        final TextView email = root.findViewById(R.id.email_edit);
        final TextView gText = root.findViewById(R.id.gender_edit);
        final EditText firstName = root.findViewById(R.id.firstName_edit);
        final EditText lastName = root.findViewById(R.id.lastName_edit);
        final EditText phone = root.findViewById(R.id.phone_edit);
        final EditText pass = root.findViewById(R.id.pass_edit);
        final EditText passCon = root.findViewById(R.id.confPassword_edit);

        sharedPrefManagerE = SharedPrefManagerE.getInstance(getActivity());
        String e=sharedPrefManagerE.readString("email", "noValue");
        email.setText(e);

        DataBaseHelper dataBaseHelper;
        dataBaseHelper = new DataBaseHelper(getActivity(), "DataBaseProject", null, 1);
        Cursor search = dataBaseHelper.searchCostomers("email", email.getText().toString());
        if (search.moveToNext()) {
            String retPass = search.getString(search.getColumnIndex("PASS_ORGINAL"));
            pass.setText(retPass);
            passCon.setText(retPass);
            String retFName= search.getString(search.getColumnIndex("FIRST_NAME"));
            firstName.setText(retFName);
            String retLName= search.getString(search.getColumnIndex("LAST_NAME"));
            lastName.setText(retLName);
            String retGen= search.getString(search.getColumnIndex("GENDER"));
            gText.setText(retGen);
            String retPhone= search.getString(search.getColumnIndex("PHONE"));
            phone.setText(retPhone);
        }

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
        alertDialogBuilder.setPositiveButton("OK", null);

        updateButton.setOnClickListener(new View.OnClickListener() {

            @Override public void onClick(View view) {
                correctFields = 0;
                if (firstName.getText().toString().isEmpty()) {
                    firstName.setText("Enter First name");
                    firstName.setTextColor(RED);
                } else {
                    if (firstName.getText().toString().length() < 3) {
                        alertDialogBuilder.setTitle("First name should at least 3 characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else if (!isAlpha(firstName.getText().toString())) {
                        alertDialogBuilder.setTitle("First name should only has characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        correctFields++;

                        //run
                    }
                }
                if (lastName.getText().toString().isEmpty()) {
                    lastName.setText("Enter Last name");
                    lastName.setTextColor(RED);
                } else {
                    if (lastName.getText().toString().length() < 3) {
                        alertDialogBuilder.setTitle("Last name should at least 3 characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else if (!isAlpha(lastName.getText().toString())) {
                        alertDialogBuilder.setTitle("Last name should only has characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        correctFields++;
                        //run
                    }
                }
                if (pass.getText().toString().isEmpty()) {
                    pass.setText("Enter password");
                    pass.setTextColor(RED);
                } else {
                    if (!validPassword(pass.getText().toString())) {
                        alertDialogBuilder.setTitle("Invalid password,password must contain 1 capital char,1 small char,1 number,1 special char");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        if (pass.getText().toString().compareTo(passCon.getText().toString()) == 0) {
                            //run
                            correctFields++;
                        } else {
                            alertDialogBuilder.setTitle("Passwords did not match");
                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();
                        }

                    }
                }
                if (passCon.getText().toString().isEmpty()) {
                    passCon.setText("Enter confirm password");
                    passCon.setTextColor(RED);
                }

                if (phone.getText().toString().isEmpty()) {
                    phone.setText("Enter phone number");
                    phone.setTextColor(RED);
                } else {
                    if (!correctFieldsPhone(phone.getText().toString())) {
                        alertDialogBuilder.setTitle("Wrong phone number, at least 10 digits starting with 05");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        //run
                        correctFields++;
                    }
                }

                if (correctFields == 4) {
                    // save in DB

                    String hashedPassword= null;

                    try {
                        hashedPassword = toHexString(getSHA(pass.getText().toString()));

                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    }
                    alertDialogBuilder.setTitle("Updated successfully");
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                    Customer newCustomer=new Customer(email.getText().toString().trim(),firstName.getText().toString().trim(), lastName.getText().toString().trim(), hashedPassword,phone.getText().toString().trim(),gText.getText().toString().trim());
                    DataBaseHelper dataBaseHelper = new DataBaseHelper(getActivity(), "DataBaseProject", null, 1);
                    dataBaseHelper.updateCustomer(newCustomer,pass.getText().toString());


                }
            }
        });


        return root;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ProfileViewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);
        // TODO: Use the ViewModel
    }
    public boolean isAlpha(String name) {
        return name.matches("[a-zA-Z]+");
    }

    public boolean validPassword(String pass) {
        String regixCapitalChar = ".*[A-Z]+.*";
        String regixSmallChar = ".*[a-z]+.*";
        String regixDig = ".*[0-9]+.*";
        String regixspecial = ".*[^a-zA-Z0-9 ]+.*";
        Pattern cap = Pattern.compile(regixCapitalChar);
        Pattern small = Pattern.compile(regixSmallChar);
        Pattern num = Pattern.compile(regixDig);
        Pattern special = Pattern.compile(regixspecial);
        Matcher match1 = cap.matcher(pass);
        Matcher match2 = small.matcher(pass);
        Matcher match3 = num.matcher(pass);
        Matcher match4 = special.matcher(pass);


        return pass.length() >= 4 && match1.matches() && match2.matches() && match3.matches() && match4.matches();

    }

    public boolean correctFieldsPhone(String phone) {
        return phone.matches("05[0-9]{8,}");
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

}