package birzeit.edu.CustomerPackage.ui.carMenu;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

import birzeit.edu.CustomerPackage.HomeActivity;
import birzeit.edu.R;
import birzeit.edu.logAndsign.LogIn;
import birzeit.edu.logAndsign.SharedPrefManagerE;

import static birzeit.edu.CustomerPackage.ui.carMenu.CarFragment.carId;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder>{
    private static final String TAG ="Adapter";
    SharedPrefManagerE sharedPrefManagerE;
    private ArrayList<String> carInfo=new ArrayList<>();
    private Context context;

    public Adapter(ArrayList<String> carInfo, Context context) {
        this.carInfo = carInfo;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        Log.d(TAG, "onBindViewHolder: called.");

        holder.text.setText(carInfo.get(position));

        //holder.image.setImageURI(Uri.parse("https://firebasestorage.googleapis.com/v0/b/advancelab-1f5b5.appspot.com/o/images%2F48.jpg?alt=media&token=b2695252-126f-4eef-941a-8e6edfad01de.jpg?alt=media&token=b2695252-126f-4eef-941a-8e6edfad01de"));
        // holder.image.setImageURI();
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sharedPrefManagerE = SharedPrefManagerE.getInstance(context);
                sharedPrefManagerE.writeString("position",carId.get(position));
                Intent intent = new Intent(context, SelectedItem.class);
                intent.putExtra("title", holder.getAdapterPosition());
                //intent.putExtra("image_name", mImageNames.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carInfo.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView text;
        RelativeLayout parent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            text=itemView.findViewById(R.id.carView);
            parent=itemView.findViewById(R.id.parent_layout);
        }
    }

    //Only remove functions are shown
    public void removeItem(int position) {
        carInfo.remove(position);
        notifyItemRemoved(position);
    }
}
