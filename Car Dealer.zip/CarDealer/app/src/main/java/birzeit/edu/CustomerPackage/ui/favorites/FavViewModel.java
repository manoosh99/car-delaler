package birzeit.edu.CustomerPackage.ui.favorites;

import androidx.lifecycle.ViewModel;

public class FavViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}