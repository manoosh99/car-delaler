package birzeit.edu.RESTcon;

import android.app.Activity;
import android.os.AsyncTask;

import java.util.List;

import birzeit.edu.MainActivity;

public class ConnectionAsyncTask extends AsyncTask<String, String, String> {
    Activity activity;

    public ConnectionAsyncTask(Activity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {

        super.onPreExecute();

    }

    @Override
    protected String doInBackground(String... params) {
        String data = HttpManager.getData(params[0]);
        return data;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try {
            List<Car> car = CarJasonParser.getObjectFromJason(s);

            ((MainActivity) activity).saveCarList(car);
            ((MainActivity) activity).connectionSuccess(true);

        }
        catch (Exception e)
        {
            e.printStackTrace();
           ((MainActivity) activity).connectionSuccess(false);
        }
    }
}