package birzeit.edu.CustomerPackage.ui.carMenu;

import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProviders;

import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.Pattern;

import birzeit.edu.CustomerPackage.ui.Findus.FindusViewModel;
import birzeit.edu.CustomerPackage.ui.favorites.SelectedItem;
import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;
import birzeit.edu.RESTcon.Car;
import birzeit.edu.logAndsign.SharedPrefManager;
import birzeit.edu.logAndsign.SharedPrefManagerE;

public class CarFragment extends Fragment {

    private CarViewModel carViewModel;

    SharedPrefManagerE sharedPrefManagerE ;
    private ArrayList<String> carInfo=new ArrayList<>();
    public static ArrayList<String> carId=new ArrayList<>();
    public static CarFragment newInstance() {
        return new CarFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        carViewModel =
                ViewModelProviders.of(this).get(CarViewModel.class);
        final View root = inflater.inflate(R.layout.car_fragment, container, false);

        initCars();
        RecyclerView rv=root.findViewById(R.id.carList);
        final Adapter adapter=new Adapter(carInfo,getActivity());
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(getActivity()));


        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        alertDialogBuilder.setPositiveButton("OK", null);

        final CheckBox t= root.findViewById(R.id.t);
        final CheckBox f= root.findViewById(R.id.f);

        final EditText min= root.findViewById(R.id.min);
        final EditText max= root.findViewById(R.id.max);

        final EditText model= root.findViewById(R.id.model_filter);

        Button apply= root.findViewById(R.id.apply);

        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int filters=0;
                String sql = "";
                if(!model.getText().toString().isEmpty()){
                    sql+="MODEL ="+"\""+model.getText().toString()+"\"";
                    filters+=1;
                }
                if(!min.getText().toString().isEmpty()){
                    String decimalPattern = "\\d+(\\.\\d+)?";
                    boolean match = Pattern.matches(decimalPattern,  min.getText().toString().trim());
                    if(match) {

                        if(filters>0 ){
                            sql += " and PRICE >=" + min.getText().toString();
                        }else
                            sql += "  PRICE >=" + min.getText().toString();
                        filters+=1;
                    }else
                    {
                        alertDialogBuilder.setTitle("Min Field must be numeric");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }
                }
                if(!max.getText().toString().isEmpty()){
                    String decimalPattern = "([0-9]*)([0-9]*)";
                    boolean match = Pattern.matches(decimalPattern,  max.getText().toString().trim());
                    if(match) {

                        if(filters>0 ){
                            sql += " and PRICE <=" + max.getText().toString();
                        }else
                            sql += "  PRICE <=" + max.getText().toString();
                        filters+=1;
                    }else
                    {
                        alertDialogBuilder.setTitle("Max Field must be numeric");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }
                }
                if(t.isChecked() && !f.isChecked()){
                    if(filters>0 ){
                        sql += " and ACCIDENTS =1";
                    }else
                        sql += " ACCIDENTS =1";
                    filters+=1;

                }else if(!t.isChecked() && f.isChecked()){
                    if(filters>0 ){
                        sql += " and ACCIDENTS =0";
                    }else
                        sql += " ACCIDENTS =0";
                    filters+=1;
                }else{

                    if(filters>0 ){
                        sql += " and (ACCIDENTS =0 or ACCIDENTS=1)";
                    }else
                        sql += " (ACCIDENTS =0 or ACCIDENTS=1)";
                    filters+=1;

                    filters+=1;
                }

                //delete old and prepare new
                if(filters>0){
                    carInfo.clear();
                    carId.clear();
                    RecyclerView rv=root.findViewById(R.id.carList);
                    final Adapter adapter=new Adapter(carInfo,getActivity());
                    rv.setAdapter(adapter);
                    rv.setLayoutManager(new LinearLayoutManager(getActivity()));

                    final DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext(), "DataBaseProject", null, 1);
                    final Cursor ret = dataBaseHelper.getFilteredCar(sql);

                    while (ret.moveToNext())
                    {
                        int year=Integer.parseInt(ret.getString(ret.getColumnIndex("YEAR")));
                        double price=Double.parseDouble(ret.getString(ret.getColumnIndex("PRICE")));
                        boolean accidents;
                        accidents= !ret.getString(ret.getColumnIndex("ACCIDENTS")).equals("0");
                        Car car=new Car(year,ret.getString(ret.getColumnIndex("MAKE")), ret.getString(ret.getColumnIndex("DISTANCE")),
                                ret.getString(ret.getColumnIndex("MODEL")),price,accidents);
                       carInfo.add(car.toString());
                        carId.add( ret.getString(ret.getColumnIndex("ID")));
                        RecyclerView rv1=root.findViewById(R.id.carList);
                        final Adapter adapter1=new Adapter(carInfo,getActivity());
                        rv1.setAdapter(adapter1);
                        rv1.setLayoutManager(new LinearLayoutManager(getActivity()));
                    }

                    Toast toast =Toast.makeText(getActivity(),"Updated", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });


        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        carViewModel = ViewModelProviders.of(this).get(CarViewModel.class);
        // TODO: Use the ViewModel
    }

    private void initCars(){

        final DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext(), "DataBaseProject", null, 1);
        final Cursor ret = dataBaseHelper.getAllCar();

        while (ret.moveToNext())
        {
            int year=Integer.parseInt(ret.getString(ret.getColumnIndex("YEAR")));
            double price=Double.parseDouble(ret.getString(ret.getColumnIndex("PRICE")));
            boolean accidents;
            accidents= !ret.getString(ret.getColumnIndex("ACCIDENTS")).equals("0");
            Car car=new Car(year,ret.getString(ret.getColumnIndex("MAKE")), ret.getString(ret.getColumnIndex("DISTANCE")),
                    ret.getString(ret.getColumnIndex("MODEL")),price,accidents);
            carInfo.add(car.toString());
            carId.add( ret.getString(ret.getColumnIndex("ID")));
        }
    }

}