package birzeit.edu.logAndsign;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import birzeit.edu.CustomerPackage.HomeActivity;
import birzeit.edu.DB.Customer;
import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;

import static android.graphics.Color.RED;

public class SignUp extends AppCompatActivity {
    int correctFields = 0;
    SharedPrefManagerE sharedPrefManagerE;
    SharedPrefManager sharedPrefManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Button signUp = findViewById(R.id.signUp);

        final EditText firstName = findViewById(R.id.firstName);
        final EditText lastName = findViewById(R.id.lastName);
        final EditText email = findViewById(R.id.email);
        final EditText pass = findViewById(R.id.pass);
        final EditText con_pass = findViewById(R.id.confPassword);
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        final EditText phone = findViewById(R.id.phone);
        final CheckBox showPass= findViewById(R.id.show);

        final Spinner gender = findViewById(R.id.gender);

        final CheckBox rem = findViewById(R.id.rememberMe);
        sharedPrefManager = SharedPrefManager.getInstance(SignUp.this);

        alertDialogBuilder.setPositiveButton("OK", null);
        showPass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    // show password
                    con_pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                } else {
                    // hide password
                    con_pass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    pass.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                correctFields = 0;
                if (firstName.getText().toString().isEmpty()) {
                    firstName.setText("Enter First name");
                    firstName.setTextColor(RED);
                } else {
                    if (firstName.getText().toString().length() < 3) {
                        alertDialogBuilder.setTitle("First name should at least 3 characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else if (!isAlpha(firstName.getText().toString())) {
                        alertDialogBuilder.setTitle("First name should only has characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        correctFields++;
                        //run
                    }
                }
                if (lastName.getText().toString().isEmpty()) {
                    lastName.setText("Enter Last name");
                    lastName.setTextColor(RED);
                } else {
                    if (lastName.getText().toString().length() < 3) {
                        alertDialogBuilder.setTitle("Last name should at least 3 characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else if (!isAlpha(lastName.getText().toString())) {
                        alertDialogBuilder.setTitle("Last name should only has characters");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        correctFields++;
                        //run
                    }
                }

                if (email.getText().toString().isEmpty()) {
                    email.setText("Enter email");
                    email.setTextColor(RED);
                } else {
                    if (validEmail(email.getText().toString())) {
                        //run
                       DataBaseHelper dataBaseHelper = new DataBaseHelper(SignUp.this, "DataBaseProject", null, 1);
                        Cursor search = dataBaseHelper.searchCostomers("email", email.getText().toString());
                        if(search.moveToNext())
                        {
                            alertDialogBuilder.setTitle("Email is used");
                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();
                        }
                        else {
                            correctFields++;
                        }
                    } else {
                        alertDialogBuilder.setTitle("Invalid email, please enter a correct email");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }
                }
                if (pass.getText().toString().isEmpty()) {
                    pass.setText("Enter password");
                    pass.setTextColor(RED);
                } else {
                    if (!validPassword(pass.getText().toString())) {
                        alertDialogBuilder.setTitle("Invalid password,password must contain 1 capital char,1 small char,1 number,1 special char");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        if (pass.getText().toString().compareTo(con_pass.getText().toString()) == 0) {
                            //run
                            correctFields++;
                        } else {
                            alertDialogBuilder.setTitle("Passwords did not match");
                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();
                        }

                    }
                }
                if (con_pass.getText().toString().isEmpty()) {
                    con_pass.setText("Enter confirm password");
                    con_pass.setTextColor(RED);
                }

                if (phone.getText().toString().isEmpty()) {
                    phone.setText("Enter phone number");
                    phone.setTextColor(RED);
                } else {
                    if (!correctFieldsPhone(phone.getText().toString())) {
                        alertDialogBuilder.setTitle("Wrong phone number, at least 10 digits starting with 05");
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        //run
                        correctFields++;
                    }
                }

                if (correctFields == 5) {
                    // save in DB
                    String hashedPassword= null;

                   try {
                        hashedPassword = toHexString(getSHA(pass.getText().toString()));

                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    }
                    //save logged user email
                    sharedPrefManagerE = SharedPrefManagerE.getInstance(SignUp.this);
                    sharedPrefManagerE.writeString("email", email.getText().toString());
                    if (rem.isChecked()) {

                        sharedPrefManager.writeString("userName", email.getText().toString());
                        sharedPrefManager.writeString("password", pass.getText().toString());



                    } else {
                        sharedPrefManager.delete("userName");
                        sharedPrefManager.delete("password");
                    }

                    Customer newCustomer=new Customer(email.getText().toString(),firstName.getText().toString(), lastName.getText().toString(), hashedPassword,phone.getText().toString(),gender.getSelectedItem().toString());
                    DataBaseHelper dataBaseHelper = new DataBaseHelper(SignUp.this, "DataBaseProject", null, 1);
                     dataBaseHelper.insertCustomer(newCustomer,pass.getText().toString());

                    Intent intent = new Intent(SignUp.this, HomeActivity.class);
                    SignUp.this.startActivity(intent);
                    finish();

                }
            }
        });


    }

    public boolean isAlpha(String name) {
        return name.matches("[a-zA-Z]+");
    }

    public boolean validEmail(String email) {
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();

    }

    public boolean validPassword(String pass) {
        String regixCapitalChar = ".*[A-Z]+.*";
        String regixSmallChar = ".*[a-z]+.*";
        String regixDig = ".*[0-9]+.*";
        String regixspecial = ".*[^a-zA-Z0-9 ]+.*";
        Pattern cap = Pattern.compile(regixCapitalChar);
        Pattern small = Pattern.compile(regixSmallChar);
        Pattern num = Pattern.compile(regixDig);
        Pattern special = Pattern.compile(regixspecial);
        Matcher match1 = cap.matcher(pass);
        Matcher match2 = small.matcher(pass);
        Matcher match3 = num.matcher(pass);
        Matcher match4 = special.matcher(pass);


        return pass.length() >= 4 && match1.matches() && match2.matches() && match3.matches() && match4.matches();

    }

    public boolean correctFieldsPhone(String phone) {
        return phone.matches("05[0-9]{8,}");
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
                Intent intent = new Intent(SignUp.this, logOrSign.class);
                SignUp.this.startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
