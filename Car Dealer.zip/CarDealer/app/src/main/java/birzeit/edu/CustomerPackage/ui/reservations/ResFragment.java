package birzeit.edu.CustomerPackage.ui.reservations;

import androidx.lifecycle.ViewModelProviders;

import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

import birzeit.edu.CustomerPackage.ui.carMenu.SelectedItem;
import birzeit.edu.CustomerPackage.ui.reservations.Adapter;
import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;
import birzeit.edu.RESTcon.Car;
import birzeit.edu.logAndsign.SharedPrefManagerE;

public class ResFragment extends Fragment {

    private ResViewModel resViewModel;
    SharedPrefManagerE sharedPrefManagerE;
    private ArrayList<String> resInfo=new ArrayList<>();

    public static ResFragment newInstance() {
        return new ResFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        resViewModel =
                ViewModelProviders.of(this).get(ResViewModel.class);
        View root = inflater.inflate(R.layout.res_fragment, container, false);


        sharedPrefManagerE= SharedPrefManagerE.getInstance(getActivity());
        String email = sharedPrefManagerE.readString("email", "noValue");

        initRes(email);
        RecyclerView rv=root.findViewById(R.id.resList);
        Adapter adapter=new Adapter(resInfo,getActivity());
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(getActivity()));

        return root;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        resViewModel = ViewModelProviders.of(this).get(ResViewModel.class);
        // TODO: Use the ViewModel
    }


    private void initRes(String email){

        DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext(), "DataBaseProject", null, 1);
        Cursor ret = dataBaseHelper.getResAndCar(email);
        while (ret.moveToNext())
        {
            int year=Integer.parseInt(ret.getString(ret.getColumnIndex("YEAR")));
            double price=Double.parseDouble(ret.getString(ret.getColumnIndex("PRICE")));
            boolean accidents;
            accidents= !ret.getString(ret.getColumnIndex("ACCIDENTS")).equals("0");

            Car car=new Car(year,ret.getString(ret.getColumnIndex("MAKE")), ret.getString(ret.getColumnIndex("DISTANCE")),
                    ret.getString(ret.getColumnIndex("MODEL")),price,accidents);
            resInfo.add("Reservation time : "+ret.getString(ret.getColumnIndex("RTIME"))+
                    "\n Reservation date : "+ret.getString(ret.getColumnIndex("RDATE"))+"\n\n"+car.toString());


        }

    }

}