package birzeit.edu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.RESTcon.Car;
import birzeit.edu.RESTcon.ConnectionAsyncTask;
import birzeit.edu.logAndsign.SignUp;
import birzeit.edu.logAndsign.logOrSign;

public class MainActivity extends AppCompatActivity {

    Button con;
    Car car;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        con = findViewById(R.id.connect);

        con.startAnimation(AnimationUtils.loadAnimation(MainActivity.this,R.anim.trans));
        con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectionAsyncTask connectionAsyncTask = new ConnectionAsyncTask(MainActivity.this);
                connectionAsyncTask.execute("https://firebasestorage.googleapis.com/v0/b/advance-proj1.appspot.com/o/data.json?alt=media&token=503ffc5e-9131-4572-ab9f-49910746c63f");

            }
        });

    }
    public void connectionSuccess(boolean success){
        if (success) {

            DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this, "DataBaseProject", null, 1);

            for (Car car : Car.carsList){
                dataBaseHelper.insertCar(car);
            }
            Intent intent = new Intent(MainActivity.this, logOrSign.class);
            MainActivity.this.startActivity(intent);
            finish();
            //
        } else {
            Toast toast = Toast.makeText(MainActivity.this, "\n Connection Failed \n", Toast.LENGTH_SHORT);
            toast.show();

        }
    }

    public void saveCarList(List<Car> cars){

        Car.carsList = cars;


    }

}