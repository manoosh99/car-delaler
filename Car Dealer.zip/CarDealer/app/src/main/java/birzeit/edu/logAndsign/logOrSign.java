package birzeit.edu.logAndsign;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import birzeit.edu.MainActivity;
import birzeit.edu.R;

public class logOrSign extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_or_sign);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        final Button log = findViewById(R.id.login);
        log.startAnimation(AnimationUtils.loadAnimation(logOrSign.this,R.anim.rotate));
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(logOrSign.this, LogIn.class);
                logOrSign.this.startActivity(intent);
                finish();
            }
        });

        final Button sign = findViewById(R.id.sign);
        sign.startAnimation(AnimationUtils.loadAnimation(logOrSign.this,R.anim.rotate));
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(logOrSign.this, SignUp.class);
                logOrSign.this.startActivity(intent);
                finish();
            }
        });


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // todo: goto back activity from here
                Intent intent = new Intent(logOrSign.this, MainActivity.class);
                logOrSign.this.startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}