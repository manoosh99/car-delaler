package birzeit.edu.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import birzeit.edu.RESTcon.Car;


public class DataBaseHelper  extends  android.database.sqlite.SQLiteOpenHelper{
    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE CUSTOMER(EMAIL TEXT PRIMARY KEY,FIRST_NAME TEXT,LAST_NAME TEXT,PASSWORD TEXT, PHONE TEXT,GENDER TEXT,PASS_ORGINAL TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE CAR(ID INTEGER PRIMARY KEY AUTOINCREMENT,YEAR INTEGER,MAKE TEXT,DISTANCE TEXT,MODEL TEXT, PRICE DOUBLE,ACCIDENTS BOOLEAN,UNIQUE(MAKE,DISTANCE,MODEL,YEAR,PRICE,ACCIDENTS))");
        sqLiteDatabase.execSQL("CREATE TABLE FAVORITES(ID INTEGER,EMAIL TEXT,PRIMARY KEY(ID,EMAIL))");
        sqLiteDatabase.execSQL("CREATE TABLE RESERVATIONS(RID INTEGER PRIMARY KEY,ID INTEGER,EMAIL TEXT,RTIME TEXT,RDATE TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertCustomer(Customer customer, String pass) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("EMAIL", customer.getEmail());
        contentValues.put("FIRST_NAME", customer.getFirstName());
        contentValues.put("LAST_NAME", customer.getLastName());
        contentValues.put("PASSWORD", customer.getPassword());
        contentValues.put("PHONE", customer.getPhone());
        contentValues.put("GENDER", customer.getGender());
        contentValues.put("PASS_ORGINAL", pass);
        sqLiteDatabase.insert("CUSTOMER", null, contentValues);
    }
    public int updateCustomer(Customer customer, String pass)
    {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("FIRST_NAME", customer.getFirstName());
        contentValues.put("LAST_NAME", customer.getLastName());
        contentValues.put("PASSWORD", customer.getPassword());
        contentValues.put("PHONE", customer.getPhone());
        contentValues.put("GENDER", customer.getGender());
        contentValues.put("PASS_ORGINAL", pass);
        return sqLiteDatabase.update("CUSTOMER",contentValues,"EMAIL ="+"\""+ customer.getEmail()+"\"",null);
    }
    public void insertCar(Car car) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("YEAR", car.getYear());
        contentValues.put("MAKE",car.getMake());
        contentValues.put("DISTANCE", car.getDistance());
        contentValues.put("MODEL", car.getModel());
        contentValues.put("PRICE", car.getPrice());
        contentValues.put("ACCIDENTS", car.isAccidents());
        sqLiteDatabase.insert("CAR", null, contentValues);
    }
    public void insertRes(int carId, String email, String rdate, String time) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID",carId);
        contentValues.put("EMAIL",email);
        contentValues.put("RDATE", rdate);
        contentValues.put("RTIME", time);
        sqLiteDatabase.insert("RESERVATIONS", null, contentValues);
    }
    public void insertFav(String email, int carId) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID",carId);
        contentValues.put("EMAIL",email);
        sqLiteDatabase.insert("FAVORITES", null, contentValues);
    }

    public Cursor getAllCar() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM CAR", null);
    }
    public Cursor getFav(String email,String pos) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query=" Select * FROM FAVORITES WHERE  EMAIL= "+ "\""+ email+"\""+" LIMIT "+pos;
        return sqLiteDatabase.rawQuery(query, null);
    }

    public void deleteFav(String email,Integer ID)
    {

        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        sqLiteDatabase.delete("FAVORITES","email =\""+email+"\" and ID=\""+ID+"\"",null);
    }
    public void deleteCars()
    {

        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        sqLiteDatabase.delete("CAR",null,null);
    }
    public Cursor getRes(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM RESERVATIONS WHERE EMAIL="+"\""+ email+"\"";
        return sqLiteDatabase.rawQuery(query, null);
    }
    public Cursor getCars(String searchType, String value) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM CAR WHERE "+searchType+"=\""+ value+"\"";
        return sqLiteDatabase.rawQuery(query, null);
    }
    public  Cursor searchCostomers(String searchType,String value)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM CUSTOMER WHERE "+searchType+"=\""+ value+"\"";
        return sqLiteDatabase.rawQuery(query, null);


    }
    public  Cursor searchCar(String searchType,String value)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM CAR WHERE "+searchType+"="+ value;
        return sqLiteDatabase.rawQuery(query, null);
    }
    public  Cursor searchCarData(String data)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM CAR WHERE "+data;
        return sqLiteDatabase.rawQuery(query, null);
    }
    public  Cursor searchFav(String ID,String email)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM FAVORITES WHERE ID="+ID+" and EMAIL ="+"\""+ email+"\"";
        return sqLiteDatabase.rawQuery(query, null);
    }
    public  Cursor getResAndCar(String email)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT RESERVATIONS.RTIME,RESERVATIONS.RDATE,CAR.* FROM RESERVATIONS INNER JOIN CAR ON CAR.ID=RESERVATIONS.ID WHERE EMAIL="+"\""+ email+"\"";
        return sqLiteDatabase.rawQuery(query, null);
    }
    public  Cursor getFavCar(String email)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT CAR.* FROM FAVORITES INNER JOIN CAR ON CAR.ID=FAVORITES.ID WHERE EMAIL="+"\""+ email+"\"";
        return sqLiteDatabase.rawQuery(query, null);
    }
    public  Cursor getFilteredCar(String sql)
    {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query="SELECT * FROM CAR WHERE "+ sql;
        return sqLiteDatabase.rawQuery(query, null);
    }
}

