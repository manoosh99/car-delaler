package birzeit.edu.CustomerPackage.ui.favorites;


import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;
import birzeit.edu.logAndsign.SharedPrefManagerE;


public class SelectedItem extends AppCompatActivity {
    int fav=0;
    AlertDialog.Builder alert;
    SharedPrefManagerE sharedPrefManagerE= SharedPrefManagerE.getInstance(SelectedItem.this);


    LinearLayout ly;
    LinearLayout lv;
    int qt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_item);


        final String email = sharedPrefManagerE.readString("email", "noValue");

        String pos=sharedPrefManagerE.readString("favPosition", "noValue");
        final int position=Integer.parseInt(pos.trim());


        Button b= findViewById(R.id.res);
        final ImageView im= findViewById(R.id.favor);
        final  DataBaseHelper dataBaseHelper = new DataBaseHelper(SelectedItem.this, "DataBaseProject", null, 1);
        final Cursor search = dataBaseHelper.getFav(email,pos);

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SelectedItem.this);
        alertDialogBuilder.setPositiveButton("OK", null);

        String ID="";
        while (search.moveToNext())
        {
             ID=search.getString(search.getColumnIndex("ID"));
        }
        getIncomingIntent(ID);


        final EditText date= findViewById(R.id.date);
        final EditText time= findViewById(R.id.time);


        final int finalID = Integer.parseInt(ID);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String regex =  "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$";
                Pattern pattern = Pattern.compile(regex);
                 Matcher matcher = pattern.matcher(date.getText().toString());
                 String TIME24HOURS_PATTERN = "([01]?[0-9]|2[0-3]):[0-5][0-9]";
                 pattern = Pattern.compile(TIME24HOURS_PATTERN);
                 Matcher  matcher1 = pattern.matcher(time.getText().toString());
                if (matcher.matches() && matcher1.matches() ) {
                    dataBaseHelper.insertRes(finalID, email, date.getText().toString(), time.getText().toString());
                    Toast toast = Toast.makeText(SelectedItem.this, "Reserved Successfully", Toast.LENGTH_SHORT);
                    toast.show();
                }else{
                    alertDialogBuilder.setTitle("Check date and time formats");
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
        im.setVisibility(View.INVISIBLE);

    }
    private void getIncomingIntent(String pos){
        //Log.d(TAG, "getIncomingIntent: checking for incoming intents.");

        final  DataBaseHelper dataBaseHelper = new DataBaseHelper(SelectedItem.this, "DataBaseProject", null, 1);
        final Cursor ret = dataBaseHelper.searchCar("ID",pos);

            while (ret.moveToNext())
            {

                if(pos.compareTo(ret.getString(ret.getColumnIndex("ID")))==0)
                {

                    setInfo(ret.getString(ret.getColumnIndex("MAKE")),
                                ret.getString(ret.getColumnIndex("YEAR")),
                                ret.getString(ret.getColumnIndex("MODEL")),
                                ret.getString(ret.getColumnIndex("DISTANCE")),
                                ret.getString(ret.getColumnIndex("PRICE")),
                                ret.getString(ret.getColumnIndex("ACCIDENTS")));

                }
            }

    }

    private void setInfo(String MAKE,String YEAR,String MODEL,String DISTANCE,String PRICE,String ACCIDENTS){
        //Log.d(TAG, "setImage: setting te image and name to widgets.");
        TextView m = findViewById(R.id.make);
        TextView y = findViewById(R.id.year);
        TextView mo = findViewById(R.id.model);
        TextView d = findViewById(R.id.distance);
        TextView p = findViewById(R.id.price);
        TextView a = findViewById(R.id.accidents);

            m.setText("Make: "+MAKE);
            y.setText("Year: "+YEAR);
            mo.setText("Model: "+MODEL);
            d.setText("Distance: "+DISTANCE);
            p.setText("Price: "+PRICE);
            if (ACCIDENTS.equals("1"))
                 a.setText("Accidents: True");
            else
                a.setText("Accidents: False");
    }

}
