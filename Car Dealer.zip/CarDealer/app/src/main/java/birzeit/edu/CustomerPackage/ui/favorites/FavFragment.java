package birzeit.edu.CustomerPackage.ui.favorites;

import androidx.lifecycle.ViewModelProviders;

import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import birzeit.edu.DB.DataBaseHelper;
import birzeit.edu.R;

import birzeit.edu.RESTcon.Car;
import birzeit.edu.logAndsign.SharedPrefManagerE;

public class FavFragment extends Fragment {

    private FavViewModel favViewModel;
    SharedPrefManagerE sharedPrefManagerE ;
    private ArrayList<String> favInfo=new ArrayList<>();
    public static FavFragment newInstance() {
        return new FavFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        favViewModel =
                ViewModelProviders.of(this).get(FavViewModel.class);
        View root = inflater.inflate(R.layout.fav_fragment, container, false);

        sharedPrefManagerE= SharedPrefManagerE.getInstance(getContext());
        String email = sharedPrefManagerE.readString("email", "noValue");

        initFav(email);
        RecyclerView rv = root.findViewById(R.id.favList);
        Adapter adapter = new Adapter(favInfo, getActivity());
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(getActivity()));

        return root;
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        favViewModel = ViewModelProviders.of(this).get(FavViewModel.class);
        // TODO: Use the ViewModel
    }


    private void initFav(String email){

       DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext(), "DataBaseProject", null, 1);
        Cursor ret = dataBaseHelper.getFavCar(email);
        while (ret.moveToNext())
        {
            int year=Integer.parseInt(ret.getString(ret.getColumnIndex("YEAR")));
            double price=Double.parseDouble(ret.getString(ret.getColumnIndex("PRICE")));
            boolean accidents;
            accidents= !ret.getString(ret.getColumnIndex("ACCIDENTS")).equals("0");
            Car car=new Car(year,ret.getString(ret.getColumnIndex("MAKE")), ret.getString(ret.getColumnIndex("DISTANCE")),
                    ret.getString(ret.getColumnIndex("MODEL")),price,accidents);
            favInfo.add(car.toString());

        }


    }

}