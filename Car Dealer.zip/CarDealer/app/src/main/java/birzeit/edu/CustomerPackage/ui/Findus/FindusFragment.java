package birzeit.edu.CustomerPackage.ui.Findus;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import birzeit.edu.CustomerPackage.HomeActivity;
import birzeit.edu.R;

public class FindusFragment extends Fragment {

    private FindusViewModel findusViewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        findusViewModel =
                ViewModelProviders.of(this).get(FindusViewModel.class);
        View root = inflater.inflate(R.layout.findus_fragment, container, false);
        final String TOAST_TEXT = "You can call us, send email or find our location";
        Toast toast =Toast.makeText(getActivity(),TOAST_TEXT, Toast.LENGTH_LONG);
        toast.show();
    //create buttons and find by id
        Button dialButton = root.findViewById(R.id.call);
        Button gmailButton = root.findViewById(R.id.mail);
        Button mapsButton = root.findViewById(R.id.location);

        //create listener to dial button
        dialButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {

                Intent dialIntent =new Intent();
                dialIntent.setAction(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:0599000000"));
                startActivity(dialIntent);
            }
        });

        //create a listener to mail button
        gmailButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                Intent gmailIntent =new Intent();
                gmailIntent.setAction(Intent.ACTION_SENDTO);
                gmailIntent.setType("message/rfc822");
                gmailIntent.setData(Uri.parse("mailto:CarDealer@cars.com"));//show recipient email
                gmailIntent.putExtra(Intent.EXTRA_EMAIL,new String [] {});//receives array of strings, to add more recipients add "email","email" in {}
                gmailIntent.putExtra(Intent.EXTRA_SUBJECT,"My Subject");
                gmailIntent.putExtra(Intent.EXTRA_TEXT,"Content of the message");
                startActivity(gmailIntent);
            }
        });

        //create a listener to maps button
        mapsButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                Intent mapsIntent =new Intent();
                mapsIntent.setAction(Intent.ACTION_VIEW);
                mapsIntent.setData(Uri.parse("geo:19.076,72.8777"));
                startActivity(mapsIntent);
            }
        });




        return root;
    }

}